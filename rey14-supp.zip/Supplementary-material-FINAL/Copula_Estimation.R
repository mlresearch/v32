

## define example problem
#n <- 500
#p <- 2

#A <-  matrix(rnorm(p*p), p,p)

#Y <- matrix(rnorm(n*p), n,p) %*% A

#Y[,2] <- as.integer(cut(Y[,2],5, labels = 1:5))
#Y[(n-10):n,2] <- NA



GaussCop <- function(X.1, X.2, plugin.threshold = floor(nrow(X.1)/3),  NSCAN = 100, NREP = 20){

  NTOT <- NSCAN + NREP

  Y <- cbind(X.1,X.2)
  n <- dim(Y)[1]
  p <- dim(Y)[2]


  impute <- any(is.na(Y))
  Y.imp.avg <- matrix(0,n,p)
  Z.avg <-  matrix(0,n,p)


  
########## starting values


##############
  R <- NULL
  for(j in 1:p) {
    R<-cbind(R, match(Y[,j],sort(unique(Y[,j]))))
  }
  
  Rlevels <- apply(R,2,max,na.rm=TRUE)
  Ranks <- apply(Y,2,rank,ties.method="max",na.last="keep")
  
  N <- apply(!is.na(Ranks),2,sum)
  U <- t( t(Ranks)/(N+1))
  Z <- qnorm(U)
  Z.orig <- Z
  Zfill <- matrix(rnorm(n*p),n,p)
  Z[is.na(Y)] <- Zfill[is.na(Y) ]
  S <- cov(Z)
 
  B0 <- diag(1e-4,p,p)
  d0 <- p+1

  B <- solve(S + B0)
  C.avg <- matrix(0,p,p)
  
######################
 
  plugin.marginal=(apply(Y,2,function(x){ length(unique(x))})>plugin.threshold)
  P.list <- list()
  
  
########## start of Gibbs sampling scheme
  for(nscan in 1:NTOT) {
    print(nscan)
    
#### update Z
    
    for(j in sample(1:p)) {
      
      sdj <- 1/B[j,j]
      Sjc2 <- matrix(B[-j,j]*(-sdj),ncol=1)
      sdj <- sqrt(sdj)
      muj <- Z[,-j]%*% (Sjc2)
      
      if(!plugin.marginal[j]){
        
       
        
        r <- 1
        ir <- (1:n)[R[,j]==r & !is.na(R[,j])] 
        ub <- (min( Z[ R[,j] == r+1,j],na.rm=TRUE))
        Z[ir,j] <- qnorm(runif(length(ir),0,pnorm(ub,muj[ir],sdj)),muj[ir],sdj)
        
        
        if(Rlevels[j] >= 3){
          for(r in 2:(Rlevels[j]-1)){
            ir <- (1:n)[R[,j]==r & !is.na(R[,j])]
            lb <- (max( Z[ R[,j] == r-1,j],na.rm=TRUE))
            ub <- (min( Z[ R[,j] == r+1,j],na.rm=TRUE))
            Z[ir,j] <- qnorm(runif(length(ir),pnorm(lb,muj[ir],sdj),pnorm(ub,muj[ir],sdj)),muj[ir],sdj)
          }
        }
        
        r <- Rlevels[j]
        ir <- (1:n)[R[,j]==r & !is.na(R[,j])]
        lb <- (max( Z[ R[,j] == r-1,j],na.rm=TRUE))
        Z[ir,j] <- qnorm(runif(length(ir),pnorm(lb,muj[ir],sdj),1),muj[ir],sdj)
        
      }
      ir <- (1:n)[is.na(R[,j])]
      Z[ir,j] <- rnorm(length(ir),muj[ir],sdj)
      
      
    }
    
#### update B
    B <- rWishart(1, n+d0, solve(B0 + t(Z)%*%Z))
    B <- B[,,1]
    
    
    S <- solve(B)
    C <- S/(sqrt(diag(S))%*%t(sqrt(diag(S))))
    C.avg <- C + C.avg
    Z.avg <- Z + Z.avg
    
   # print(C.avg/nscan)
    
                                        # SIG <- t(Z)%*%Z
                                        # D.SIG <- diag(SIG)^{-0.5}
                                        # print(D.SIG %*% SIG %*% D.SIG)
    
    if(impute){
      Y.imp.s <- Y
      for(j in 1:p) {
        Y.imp.s[is.na(Y[,j]),j]<-quantile(Y[,j], pnorm(Z[is.na(Y[,j]),j],0,sqrt(S[j,j])),na.rm=TRUE,type=1)
      }
      Y.imp.avg <- Y.imp.avg +  Y.imp.s
      
      w <- which(is.na(Y), arr.ind = TRUE)
                                        #cat(w,Y.imp.avg[w]/nscan,"\n")
    }
    
    if(nscan > NSCAN){
      P.list[[nscan-NSCAN]] <- C
    
    }
  
  }#end of nscan

  list(C.avg = C.avg/NSCAN, Z.avg = Z.avg/NSCAN, Y.imp.avg = Y.imp.avg/NSCAN, P.list = P.list)
}

