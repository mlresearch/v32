 
if(length(dev.list()) != 0){
  dev.off(which = dev.list())
}

scores.xy <- function(X, Y, phi.inv = qnorm((1:nrow(X))/(nrow(X)+1))){ ## computes Gaussian scores
  XY <- cbind(X,Y)
  d.x <- ncol(X)
  d.y <- ncol(Y)
  d.t <- d.x+d.y
  r.mat <-  apply(XY,2,rank)
  phi.mat <- matrix(phi.inv[r.mat],nrow=nrow(X))
 
  list(S.x = as.matrix(phi.mat[,1:d.x]), S.y = as.matrix(phi.mat[,(d.x+1):d.t]))
  
}


rank.corr.xy <- function(X, Y, phi.inv = qnorm((1:nrow(X))/(nrow(X)+1)), estimateMI = FALSE){ ## estimates rank correlation (and MI)
  XY <- cbind(X,Y)
  d.x <- ncol(X)
  d.y <- ncol(Y)
  d.t <- d.x+d.y
  r.mat <-  apply(XY,2,rank)
  phi.mat <- matrix(phi.inv[r.mat],nrow=nrow(X))
  P <- t(phi.mat) %*% phi.mat
  P <- P/P[1,1]
  P.x <-  as.matrix(P[1:d.x,1:d.x])
  P.y <-  as.matrix(P[(d.x+1):d.t,(d.x+1):d.t])
  MI <- NA
  if(estimateMI){
    MI <- 0.5*(-determinant(P)$modulus + determinant(P.x)$modulus  + determinant(P.y)$modulus )
  }
  
  list(P = as.matrix(P), P.x = P.x, P.xy = as.matrix(P[1:d.x,(d.x+1):d.t]), P.y = P.y, MI = MI) 
}



cov.xy <- function(X, Y){ ## standard covariance (just to use the same syntax as above)
  XY <- cbind(X,Y)
  d.x <- ncol(X)
  d.y <- ncol(Y)
  d.t <- d.x+d.y
  P <- cov(XY)
  list(P = as.matrix(P), P.x =  as.matrix(P[1:d.x,1:d.x]), P.xy = as.matrix(P[1:d.x,(d.x+1):d.t]), P.y = as.matrix(P[(d.x+1):d.t,(d.x+1):d.t]))
  
}

MGIB.diagonal<- function(X,Y, COPULA = TRUE, phi.inv = qnorm((1:nrow(X))/(nrow(X)+1)), kappa.max = 10, kappa.length = 50){ ## the sparse MGIB routine. Computes a list of sparse projections x along a path of constraints from kappa.max down to 0

  d.x <- ncol(X)
  d.y <- ncol(Y)
  d.t <- d.x+d.y
  n <- nrow(X)
  if(COPULA){

    P <- rank.corr.xy(X,Y, phi.inv)
   
  }else{
    P <- cov.xy(X,Y)
  }
  
  P.x <- P$P.x
  P.y <- P$P.y
  P.xy <- P$P.xy

  x <- rep(0,d.x)
  
  P.xGy <- P.x - P.xy %*%solve(P.y,t( P.xy))
  

  
  
  


  
  func <- function(x,P.x,P.xGy, kappa, eps, max.x){
    
    
    f <- determinant(P.xGy   %*% diag(x,length(x)) + diag(rep(1,length(x))))$modulus - eps * log(determinant(P.x   %*%  diag(x,length(x)) + diag(rep(1,length(x))))$modulus-kappa) -eps*(sum(log(x))) 
    
    if( is.nan(f)) f <- Inf
    f
  }
  
  grad <- function(x,P.x,P.xGy, kappa, eps, max.x){
    
    g <-  (solve(P.xGy %*% diag(x,length(x)) + diag(rep(1,length(x))) ) * P.xGy )%*% rep(1,length(x)) - eps/(determinant(P.x   %*%  diag(x,length(x)) + diag(rep(1,length(x))))$modulus -kappa) * (solve(P.x %*% diag(x,length(x)) + diag(rep(1,length(x))) ) * P.x )%*% rep(1,length(x)) - eps * x^(-1) 
    g<-as.vector(g)
    g
  }
  
  
  
  grad.diagonal <- function(x,P.x,kappa,lambda.psi,log.det.psi){
    g <- ( log.det.psi + sum(log(1/lambda.psi + x)) -kappa)^2
    g
  }
  
  
  
  
  
  mu <- eigen(P.xGy)$values
  lambda.psi <- eigen(P.x)$values
  log.det.psi <- sum(log(lambda.psi))
  
  
  
  
  kappa.arr <- seq(kappa.max,1e-3,length=kappa.length)
  
  dims <- rep(0,length(kappa.arr))
  x.arr <- matrix(0,length(kappa.arr),d.x) 
  
  
  for(i in 1:length(kappa.arr)){
    
    

    kappa <- kappa.arr[i]
    max.x <- rep(0,d.x)
  
    for(k in 1:d.x){
      max.x[k] <- (exp(kappa) -1)/P.x[k,k]
    }

 

    eps <- 0.1
  
    max.x.inv <- max.x^(-1)


    if(i==1){
      ## find a good starting point
      
      init.x <- as.vector(1/sum(max.x.inv) * rep(1,d.x))
   
    


      c <- optimize(f = grad.diagonal,  interval = c(0, init.x[1]), maximum = FALSE,tol = 1e-6,P.x = P.x, kappa = kappa, lambda.psi=lambda.psi, log.det.psi=log.det.psi)
 
      init.x <- rep(c$minimum,d.x) + 1e-2
    

      x <- init.x
  

   
     
      nonzero <- 1:d.x
      x.act <- x
      P.x.act <- P.x
      P.xGy.act <- P.xGy
    }
    
    for(j in 1:8){
      
      o <- optim(x.act, func, grad, method = "BFGS", control=list(maxit=2000,reltol = 1e-10),P.x = P.x.act,P.xGy=P.xGy.act, kappa=kappa, eps=eps^j, max.x=max.x)
      x.act <- o$par
     
    }

    x <- rep(0,d.x)
    x[nonzero] <- x.act
    x <- as.vector(x)
   
    nonzero <- which(x > 1e-2)
    if(length(nonzero) ==0){
      o <- order(x,decreasing = TRUE)
      nonzero <- o[1]
    }
  
    x.act <- x[nonzero]
    P.x.act <- P.x[nonzero,,drop=FALSE]
    P.x.act <- P.x.act[,nonzero,drop=FALSE]
    P.xGy.act <- P.xGy[nonzero,,drop=FALSE]
    P.xGy.act <- P.xGy.act[,nonzero,drop=FALSE]
    
    
    
    

    print(round(x,3))
    kappa.arr[i] <- kappa
    x.arr[i,] <- x

    
  }

  
  
  list(x = x.arr, dims = dims, P.x= P.x, P.xGy = P.xGy, kappa = kappa.arr)  
}




############ example with Gaussian data 

n <- 1000 ## size of training set
d.x <- 10 ## dimension of X
d.y <- 10 ## dimension of Y
d.t <- d.x+d.y


C <- matrix(rnorm(d.t*d.t),d.t,d.t) ## t(C) %*% C is our covariance...


phi.inv <- qnorm((1:n)/(n+1))
    
XY <- matrix(rnorm(n*d.t), n, d.t) %*%C

X <- XY[,1:d.x]
Y <-  XY[,(d.x+1):d.t]



IB <- MGIB.diagonal(X,Y, COPULA = TRUE, phi.inv,  kappa.max =10, kappa.length = 100)
P.x <- IB$P.x
P.xGy <- IB$P.xGy
kappa <- IB$kappa


## plot the solution path

A <- IB$x
A.1 <- A[,1]
plot(kappa,A.1, type = "n", ylim = c(0,max(A)))
for(i in 1:d.x){
  A.i <- A[,i]
  lines(kappa,A.i)
  text(kappa[1],max(A.i) + 1e-1,as.character(i))
}

